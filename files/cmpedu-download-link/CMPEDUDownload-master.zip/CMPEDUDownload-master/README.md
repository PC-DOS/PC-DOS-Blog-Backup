# CMPEDUDownload

机械工业出版社PDF下载器

## 使用方法

```bash
pip3 install requests --user
python3 Download.py
```

## 感谢

https://www.cnblogs.com/owasp/p/6413480.html



