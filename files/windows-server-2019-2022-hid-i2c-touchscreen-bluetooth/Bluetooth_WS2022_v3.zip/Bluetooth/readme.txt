https://docs.google.com/document/d/1vUhDGPojbITF_RvI5a73XqRMNg4oltbu-2Sq0i9hB24
